/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
self["webpackHotUpdate_N_E"]("app/page",{

/***/ "(app-pages-browser)/./src/app/components/Tokenomics/Tokenomics.module.css":
/*!*************************************************************!*\
  !*** ./src/app/components/Tokenomics/Tokenomics.module.css ***!
  \*************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

eval(__webpack_require__.ts("// extracted by mini-css-extract-plugin\nmodule.exports = {\"tokenomicsSection\":\"Tokenomics_tokenomicsSection__rLFIz\",\"tokenomicsSectionTitle\":\"Tokenomics_tokenomicsSectionTitle__GOgTS\",\"tokenomicsSectionHeading\":\"Tokenomics_tokenomicsSectionHeading__uiUfR\",\"tokenomicsSectionBody\":\"Tokenomics_tokenomicsSectionBody__I2Wrh\",\"tokenomicsSectionChartImage\":\"Tokenomics_tokenomicsSectionChartImage__CLjZp\"};\n    if(true) {\n      // 1706117664559\n      var cssReload = __webpack_require__(/*! ./node_modules/next/dist/compiled/mini-css-extract-plugin/hmr/hotModuleReplacement.js */ \"(app-pages-browser)/./node_modules/next/dist/compiled/mini-css-extract-plugin/hmr/hotModuleReplacement.js\")(module.id, {\"publicPath\":\"/_next/\",\"esModule\":false,\"locals\":true});\n      module.hot.dispose(cssReload);\n      \n    }\n  \nmodule.exports.__checksum = \"f3d85346b844\"\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwcC1wYWdlcy1icm93c2VyKS8uL3NyYy9hcHAvY29tcG9uZW50cy9Ub2tlbm9taWNzL1Rva2Vub21pY3MubW9kdWxlLmNzcyIsIm1hcHBpbmdzIjoiQUFBQTtBQUNBLGtCQUFrQjtBQUNsQixPQUFPLElBQVU7QUFDakI7QUFDQSxzQkFBc0IsbUJBQU8sQ0FBQyx3TUFBNkcsY0FBYyxzREFBc0Q7QUFDL00sTUFBTSxVQUFVO0FBQ2hCO0FBQ0E7QUFDQTtBQUNBLHlCQUF5QiIsInNvdXJjZXMiOlsid2VicGFjazovL19OX0UvLi9zcmMvYXBwL2NvbXBvbmVudHMvVG9rZW5vbWljcy9Ub2tlbm9taWNzLm1vZHVsZS5jc3M/ZGY0ZiJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBleHRyYWN0ZWQgYnkgbWluaS1jc3MtZXh0cmFjdC1wbHVnaW5cbm1vZHVsZS5leHBvcnRzID0ge1widG9rZW5vbWljc1NlY3Rpb25cIjpcIlRva2Vub21pY3NfdG9rZW5vbWljc1NlY3Rpb25fX3JMRkl6XCIsXCJ0b2tlbm9taWNzU2VjdGlvblRpdGxlXCI6XCJUb2tlbm9taWNzX3Rva2Vub21pY3NTZWN0aW9uVGl0bGVfX0dPZ1RTXCIsXCJ0b2tlbm9taWNzU2VjdGlvbkhlYWRpbmdcIjpcIlRva2Vub21pY3NfdG9rZW5vbWljc1NlY3Rpb25IZWFkaW5nX191aVVmUlwiLFwidG9rZW5vbWljc1NlY3Rpb25Cb2R5XCI6XCJUb2tlbm9taWNzX3Rva2Vub21pY3NTZWN0aW9uQm9keV9fSTJXcmhcIixcInRva2Vub21pY3NTZWN0aW9uQ2hhcnRJbWFnZVwiOlwiVG9rZW5vbWljc190b2tlbm9taWNzU2VjdGlvbkNoYXJ0SW1hZ2VfX0NMalpwXCJ9O1xuICAgIGlmKG1vZHVsZS5ob3QpIHtcbiAgICAgIC8vIDE3MDYxMTc2NjQ1NTlcbiAgICAgIHZhciBjc3NSZWxvYWQgPSByZXF1aXJlKFwiRDovcHJvamVjdHMvcGxzdC1jcnlwdG8vbm9kZV9tb2R1bGVzL25leHQvZGlzdC9jb21waWxlZC9taW5pLWNzcy1leHRyYWN0LXBsdWdpbi9obXIvaG90TW9kdWxlUmVwbGFjZW1lbnQuanNcIikobW9kdWxlLmlkLCB7XCJwdWJsaWNQYXRoXCI6XCIvX25leHQvXCIsXCJlc01vZHVsZVwiOmZhbHNlLFwibG9jYWxzXCI6dHJ1ZX0pO1xuICAgICAgbW9kdWxlLmhvdC5kaXNwb3NlKGNzc1JlbG9hZCk7XG4gICAgICBcbiAgICB9XG4gIFxubW9kdWxlLmV4cG9ydHMuX19jaGVja3N1bSA9IFwiZjNkODUzNDZiODQ0XCJcbiJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(app-pages-browser)/./src/app/components/Tokenomics/Tokenomics.module.css\n"));

/***/ })

});