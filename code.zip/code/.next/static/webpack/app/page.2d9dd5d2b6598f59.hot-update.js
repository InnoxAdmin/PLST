/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
self["webpackHotUpdate_N_E"]("app/page",{

/***/ "(app-pages-browser)/./src/app/components/Navbar/Navbar.module.css":
/*!*****************************************************!*\
  !*** ./src/app/components/Navbar/Navbar.module.css ***!
  \*****************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

eval(__webpack_require__.ts("// extracted by mini-css-extract-plugin\nmodule.exports = {\"navbarWrap\":\"Navbar_navbarWrap__mZCsO\",\"navbarBrand\":\"Navbar_navbarBrand__kypXO\",\"navbarItems\":\"Navbar_navbarItems__ne5aL\",\"navbarItem\":\"Navbar_navbarItem__S9OvV\",\"navbarLink\":\"Navbar_navbarLink__x5jY9\",\"navbarBtn\":\"Navbar_navbarBtn__BkFmh\"};\n    if(true) {\n      // 1706101289820\n      var cssReload = __webpack_require__(/*! ./node_modules/next/dist/compiled/mini-css-extract-plugin/hmr/hotModuleReplacement.js */ \"(app-pages-browser)/./node_modules/next/dist/compiled/mini-css-extract-plugin/hmr/hotModuleReplacement.js\")(module.id, {\"publicPath\":\"/_next/\",\"esModule\":false,\"locals\":true});\n      module.hot.dispose(cssReload);\n      \n    }\n  \nmodule.exports.__checksum = \"2a18cbd56e70\"\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwcC1wYWdlcy1icm93c2VyKS8uL3NyYy9hcHAvY29tcG9uZW50cy9OYXZiYXIvTmF2YmFyLm1vZHVsZS5jc3MiLCJtYXBwaW5ncyI6IkFBQUE7QUFDQSxrQkFBa0I7QUFDbEIsT0FBTyxJQUFVO0FBQ2pCO0FBQ0Esc0JBQXNCLG1CQUFPLENBQUMsd01BQTZHLGNBQWMsc0RBQXNEO0FBQy9NLE1BQU0sVUFBVTtBQUNoQjtBQUNBO0FBQ0E7QUFDQSx5QkFBeUIiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2FwcC9jb21wb25lbnRzL05hdmJhci9OYXZiYXIubW9kdWxlLmNzcz8wZjE3Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIGV4dHJhY3RlZCBieSBtaW5pLWNzcy1leHRyYWN0LXBsdWdpblxubW9kdWxlLmV4cG9ydHMgPSB7XCJuYXZiYXJXcmFwXCI6XCJOYXZiYXJfbmF2YmFyV3JhcF9fbVpDc09cIixcIm5hdmJhckJyYW5kXCI6XCJOYXZiYXJfbmF2YmFyQnJhbmRfX2t5cFhPXCIsXCJuYXZiYXJJdGVtc1wiOlwiTmF2YmFyX25hdmJhckl0ZW1zX19uZTVhTFwiLFwibmF2YmFySXRlbVwiOlwiTmF2YmFyX25hdmJhckl0ZW1fX1M5T3ZWXCIsXCJuYXZiYXJMaW5rXCI6XCJOYXZiYXJfbmF2YmFyTGlua19feDVqWTlcIixcIm5hdmJhckJ0blwiOlwiTmF2YmFyX25hdmJhckJ0bl9fQmtGbWhcIn07XG4gICAgaWYobW9kdWxlLmhvdCkge1xuICAgICAgLy8gMTcwNjEwMTI4OTgyMFxuICAgICAgdmFyIGNzc1JlbG9hZCA9IHJlcXVpcmUoXCJEOi9wcm9qZWN0cy9wbHN0LWNyeXB0by9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2NvbXBpbGVkL21pbmktY3NzLWV4dHJhY3QtcGx1Z2luL2htci9ob3RNb2R1bGVSZXBsYWNlbWVudC5qc1wiKShtb2R1bGUuaWQsIHtcInB1YmxpY1BhdGhcIjpcIi9fbmV4dC9cIixcImVzTW9kdWxlXCI6ZmFsc2UsXCJsb2NhbHNcIjp0cnVlfSk7XG4gICAgICBtb2R1bGUuaG90LmRpc3Bvc2UoY3NzUmVsb2FkKTtcbiAgICAgIFxuICAgIH1cbiAgXG5tb2R1bGUuZXhwb3J0cy5fX2NoZWNrc3VtID0gXCIyYTE4Y2JkNTZlNzBcIlxuIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(app-pages-browser)/./src/app/components/Navbar/Navbar.module.css\n"));

/***/ })

});